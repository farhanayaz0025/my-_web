import React, { useState } from 'react';
import { Flame, Check, Plus, ShoppingBag, Sparkles, RefreshCw } from 'lucide-react';
import { PizzaSize, PizzaCrust, Topping, CartItem, MenuItem } from '../types';
import { PIZZA_SIZES, PIZZA_CRUSTS, TOPPINGS_LIST } from '../data/menuData';

interface PizzaCustomizerProps {
  onAddToCart: (cartItem: CartItem) => void;
}

export const PizzaCustomizer: React.FC<PizzaCustomizerProps> = ({ onAddToCart }) => {
  const [selectedSize, setSelectedSize] = useState<PizzaSize>('10" Medium');
  const [selectedCrust, setSelectedCrust] = useState<PizzaCrust>('Regular Pan');
  const [selectedSauce, setSelectedSauce] = useState<'marinara' | 'bbq' | 'alfredo' | 'naga'>('marinara');
  const [cheeseLevel, setCheeseLevel] = useState<'regular' | 'double' | 'triple'>('regular');
  const [selectedToppings, setSelectedToppings] = useState<Topping[]>([
    TOPPINGS_LIST[1], // Beef Pepperoni
    TOPPINGS_LIST[2], // Spicy BBQ Chicken
  ]);

  const sauceNames = {
    marinara: 'Signature Tomato Marinara',
    bbq: 'Smoky BBQ Glaze',
    alfredo: 'Creamy Garlic Alfredo',
    naga: 'Fiery Naga Spicy Sauce (+৳20)',
  };

  // Base price computation
  const sizeOption = PIZZA_SIZES.find((s) => s.name === selectedSize) || PIZZA_SIZES[1];
  const crustOption = PIZZA_CRUSTS.find((c) => c.name === selectedCrust) || PIZZA_CRUSTS[0];

  const basePrice = 350; // Custom Pizza starting price
  const sizePrice = Math.round(basePrice * sizeOption.priceModifier);
  const crustPrice = crustOption.additionalCost;
  const sauceExtra = selectedSauce === 'naga' ? 20 : 0;
  const cheeseExtra = cheeseLevel === 'double' ? 60 : cheeseLevel === 'triple' ? 110 : 0;
  const toppingsPrice = selectedToppings.reduce((sum, t) => sum + t.price, 0);

  const calculatedUnitPrice = sizePrice + crustPrice + sauceExtra + cheeseExtra + toppingsPrice;

  const toggleTopping = (topping: Topping) => {
    if (selectedToppings.some((t) => t.id === topping.id)) {
      setSelectedToppings(selectedToppings.filter((t) => t.id !== topping.id));
    } else {
      setSelectedToppings([...selectedToppings, topping]);
    }
  };

  const handleAddCustomPizzaToCart = () => {
    const customMenuItem: MenuItem = {
      id: 'custom-pizza-builder',
      name: `Custom ${selectedSize} PizzaBurg`,
      banglaName: 'কাস্টম পিজ্জাবার্গ পিজ্জা',
      description: `${selectedCrust} crust with ${sauceNames[selectedSauce]}, ${cheeseLevel} cheese, topped with ${
        selectedToppings.length > 0 ? selectedToppings.map((t) => t.name).join(', ') : 'no extra toppings'
      }`,
      category: 'pizzas',
      basePrice: calculatedUnitPrice,
      image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
      rating: 5.0,
      reviewsCount: 1,
      tags: ['Custom Creation', 'Chef Special'],
    };

    const cartItem: CartItem = {
      cartId: `custom-${Date.now()}`,
      menuItem: customMenuItem,
      selectedSize,
      selectedCrust,
      customToppings: selectedToppings,
      quantity: 1,
      calculatedUnitPrice,
      specialInstructions: `Custom Pizza: Sauce: ${sauceNames[selectedSauce]}, Cheese: ${cheeseLevel}`,
    };

    onAddToCart(cartItem);
  };

  return (
    <section id="customizer" className="py-12 bg-zinc-900/80 text-white border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3.5 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5" /> Interactive Pizza Studio
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Build Your Own <span className="text-amber-400">PizzaBurg Masterpiece</span>
          </h2>
          <p className="text-sm text-zinc-300">
            Pick your dough size, stuffed crusts, sauce, double mozzarella, and toppings. Freshly baked just for you!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Controls Column */}
          <div className="lg:col-span-7 space-y-6">
            {/* Step 1: Size */}
            <div className="bg-zinc-950 p-5 rounded-3xl border border-zinc-800 space-y-3">
              <label className="text-xs uppercase font-extrabold text-amber-400 tracking-wider flex items-center justify-between">
                <span>1. Select Pizza Size</span>
                <span className="text-zinc-500 font-normal capitalize">{selectedSize}</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {PIZZA_SIZES.map((size) => {
                  const isSelected = selectedSize === size.name;
                  const price = Math.round(basePrice * size.priceModifier);
                  return (
                    <button
                      key={size.name}
                      onClick={() => setSelectedSize(size.name)}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'bg-gradient-to-br from-red-600/30 to-amber-600/30 border-amber-500 text-white shadow-lg'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-xs">{size.name}</div>
                      <div className="text-[10px] text-zinc-400 line-clamp-1">{size.description}</div>
                      <div className="mt-1 font-extrabold text-amber-400 text-xs">৳{price}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Crust */}
            <div className="bg-zinc-950 p-5 rounded-3xl border border-zinc-800 space-y-3">
              <label className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                2. Choose Crust Style
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {PIZZA_CRUSTS.map((crust) => {
                  const isSelected = selectedCrust === crust.name;
                  return (
                    <button
                      key={crust.name}
                      onClick={() => setSelectedCrust(crust.name)}
                      className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-red-950/60 border-red-500 text-white'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs">{crust.name}</div>
                        {crust.additionalCost > 0 ? (
                          <div className="text-[10px] text-amber-400 font-semibold">+৳{crust.additionalCost}</div>
                        ) : (
                          <div className="text-[10px] text-zinc-500">Standard</div>
                        )}
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-red-500" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Step 3: Sauce & Cheese */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Sauce Selection */}
              <div className="bg-zinc-950 p-5 rounded-3xl border border-zinc-800 space-y-3">
                <label className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                  3. Select Sauce Base
                </label>
                <div className="space-y-2">
                  {(['marinara', 'bbq', 'alfredo', 'naga'] as const).map((sauceKey) => (
                    <button
                      key={sauceKey}
                      onClick={() => setSelectedSauce(sauceKey)}
                      className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                        selectedSauce === sauceKey
                          ? 'bg-amber-500/20 border-amber-500 text-amber-200 font-bold'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <span>{sauceNames[sauceKey]}</span>
                      {selectedSauce === sauceKey && <Check className="w-3.5 h-3.5 text-amber-400" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Cheese Level */}
              <div className="bg-zinc-950 p-5 rounded-3xl border border-zinc-800 space-y-3">
                <label className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                  4. Cheese Level
                </label>
                <div className="space-y-2">
                  {[
                    { id: 'regular', name: 'Regular Mozzarella', cost: 0 },
                    { id: 'double', name: 'Double Mozzarella Layer', cost: 60 },
                    { id: 'triple', name: 'Triple Cheese Lava Blast', cost: 110 },
                  ].map((level) => (
                    <button
                      key={level.id}
                      onClick={() => setCheeseLevel(level.id as any)}
                      className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                        cheeseLevel === level.id
                          ? 'bg-red-950/60 border-red-500 text-white font-bold'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <div>
                        <div>{level.name}</div>
                        {level.cost > 0 && <div className="text-[10px] text-amber-400">+৳{level.cost}</div>}
                      </div>
                      {cheeseLevel === level.id && <Check className="w-3.5 h-3.5 text-red-500" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 4: Toppings Selection */}
            <div className="bg-zinc-950 p-5 rounded-3xl border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                  5. Add Your Favorite Toppings
                </label>
                <button
                  onClick={() => setSelectedToppings([])}
                  className="text-[11px] text-zinc-500 hover:text-amber-400 flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" /> Clear Toppings
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {TOPPINGS_LIST.map((topping) => {
                  const isChecked = selectedToppings.some((t) => t.id === topping.id);
                  return (
                    <button
                      key={topping.id}
                      onClick={() => toggleTopping(topping)}
                      className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                        isChecked
                          ? 'bg-gradient-to-r from-red-900/60 to-amber-900/60 border-amber-500 text-white font-bold shadow'
                          : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      <div>
                        <div>{topping.name}</div>
                        <div className="text-[10px] text-amber-400 font-bold">+৳{topping.price}</div>
                      </div>
                      {isChecked && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Live Interactive Visual Preview Column */}
          <div className="lg:col-span-5 sticky top-24 space-y-6">
            <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 text-center space-y-6 shadow-2xl relative overflow-hidden">
              <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
                Live Pizza Creation Preview
              </div>

              {/* Pizza Visual Canvas Representation */}
              <div className="relative mx-auto w-64 h-64 sm:w-72 sm:h-72 rounded-full border-4 border-amber-800/60 bg-gradient-to-br from-amber-700 via-amber-600 to-amber-800 shadow-2xl flex items-center justify-center p-3 transform transition-transform hover:scale-102">
                {/* Sauce Layer */}
                <div
                  className={`w-full h-full rounded-full transition-colors duration-500 p-3 ${
                    selectedSauce === 'marinara'
                      ? 'bg-red-700'
                      : selectedSauce === 'bbq'
                      ? 'bg-amber-950'
                      : selectedSauce === 'alfredo'
                      ? 'bg-amber-100/90'
                      : 'bg-red-800'
                  }`}
                >
                  {/* Cheese Layer */}
                  <div
                    className={`w-full h-full rounded-full border-2 border-amber-300/40 transition-all duration-500 relative flex items-center justify-center flex-wrap p-4 ${
                      cheeseLevel === 'triple'
                        ? 'bg-amber-300/90'
                        : cheeseLevel === 'double'
                        ? 'bg-amber-200/80'
                        : 'bg-amber-200/60'
                    }`}
                  >
                    {/* Visual Topping Icons scattered on dough */}
                    <div className="absolute inset-0 p-6 flex flex-wrap items-center justify-center gap-3 overflow-hidden opacity-90">
                      {selectedToppings.map((t, idx) => (
                        <span
                          key={`${t.id}-${idx}`}
                          className="bg-black/80 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-amber-500/40 shadow"
                        >
                          {t.name.split(' ')[0]}
                        </span>
                      ))}
                      {selectedToppings.length === 0 && (
                        <span className="text-zinc-800 font-extrabold text-xs uppercase tracking-widest">
                          Plain Cheese Pizza
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Price Breakdown Summary */}
              <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 space-y-2 text-xs text-left">
                <div className="flex justify-between text-zinc-300">
                  <span>Size ({selectedSize}):</span>
                  <span className="font-bold">৳{sizePrice}</span>
                </div>
                <div className="flex justify-between text-zinc-300">
                  <span>Crust ({selectedCrust}):</span>
                  <span className="font-bold">৳{crustPrice}</span>
                </div>
                {cheeseExtra > 0 && (
                  <div className="flex justify-between text-amber-400">
                    <span>Extra Cheese ({cheeseLevel}):</span>
                    <span className="font-bold">+৳{cheeseExtra}</span>
                  </div>
                )}
                {toppingsPrice > 0 && (
                  <div className="flex justify-between text-amber-400">
                    <span>Extra Toppings ({selectedToppings.length}):</span>
                    <span className="font-bold">+৳{toppingsPrice}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm font-black text-white">
                  <span>Total Custom Price:</span>
                  <span className="text-amber-400 text-base">৳{calculatedUnitPrice}</span>
                </div>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddCustomPizzaToCart}
                className="w-full bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl shadow-red-900/40 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <ShoppingBag className="w-5 h-5" />
                <span>Add Custom Pizza to Order (৳{calculatedUnitPrice})</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
