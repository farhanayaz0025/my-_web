import React from 'react';
import { MapPin, Phone, Clock, Star, ExternalLink, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-950 text-zinc-400 border-t border-zinc-900 pt-12 pb-8 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-600 to-amber-500 p-0.5">
                <div className="w-full h-full bg-zinc-900 rounded-[10px] flex items-center justify-center font-black text-amber-400 text-lg">
                  PB
                </div>
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">
                PIZZA<span className="text-red-500">BURG</span> Khulna
              </span>
            </div>
            <p className="text-zinc-400 leading-relaxed">
              Khulna's top rated pizza destination (4.9 ★ based on 1,926 reviews). Fresh dough made daily with 100% Mozzarella cheese.
            </p>
            <div className="flex items-center gap-1 text-amber-400 font-bold">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
              ))}
              <span className="ml-1 text-zinc-300">4.9 / 5.0 Rating</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white uppercase tracking-wider text-xs">Menu & Deals</h4>
            <ul className="space-y-2">
              <li>
                <a href="#menu" className="hover:text-amber-400 transition-colors">
                  Signature Pizzas
                </a>
              </li>
              <li>
                <a href="#menu" className="hover:text-amber-400 transition-colors">
                  Smash Burgers & Subs
                </a>
              </li>
              <li>
                <a href="#combos" className="hover:text-amber-400 transition-colors">
                  Khulna Student Deal (৳299)
                </a>
              </li>
              <li>
                <a href="#customizer" className="hover:text-amber-400 transition-colors">
                  Build Custom Pizza
                </a>
              </li>
              <li>
                <a href="#ai-assistant" className="hover:text-amber-400 transition-colors">
                  AI Meal Recommendation
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact & Hours */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white uppercase tracking-wider text-xs">Contact & Hours</h4>
            <div className="space-y-2">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>12 KDA Ave, Khulna 9100 (Shimla Plaza)</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a href="tel:01404461257" className="text-amber-400 hover:underline font-bold">
                  01404-461257
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Open Daily: 11:00 AM – 11:00 PM</span>
              </p>
            </div>
          </div>

          {/* Col 4: Online Ordering */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-white uppercase tracking-wider text-xs">Online Partners</h4>
            <p>Order directly on our site for local delivery in Khulna or visit foodpanda.</p>
            <a
              href="https://www.foodpanda.com.bd"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-pink-700 hover:bg-pink-600 text-white font-bold px-4 py-2 rounded-xl text-xs transition-colors"
            >
              <span>Order on foodpanda</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        <div className="pt-8 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-zinc-500 text-[11px]">
          <p>© {new Date().getFullYear()} PizzaBurg Khulna (Shimla Plaza, 12 KDA Ave). All rights reserved.</p>
          <p className="flex items-center gap-1">
            Handcrafted with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for Khulna Pizza Lovers
          </p>
        </div>
      </div>
    </footer>
  );
};
