import React, { useState, useEffect } from 'react';
import { X, CheckCircle, Clock, Phone, Flame, Bike, MapPin, Sparkles } from 'lucide-react';
import { Order } from '../types';

interface OrderTrackerModalProps {
  order: Order | null;
  onClose: () => void;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({ order, onClose }) => {
  const [step, setStep] = useState<number>(0);
  const [minutesLeft, setMinutesLeft] = useState<number>(order ? order.estimatedMinutes : 25);

  useEffect(() => {
    if (!order) return;

    // Simulate progress sequence
    const interval = setInterval(() => {
      setStep((prev) => {
        if (prev < 4) return prev + 1;
        return prev;
      });
      setMinutesLeft((prev) => Math.max(1, prev - 5));
    }, 6000);

    return () => clearInterval(interval);
  }, [order]);

  if (!order) return null;

  const stepsList = [
    { title: 'Order Received', desc: 'PizzaBurg team accepted order at Shimla Plaza' },
    { title: 'Kneading Dough & Sauces', desc: 'Hand-tossing dough with 100% Mozzarella' },
    { title: 'Baking in Stone Oven', desc: 'Crisping crust at 450°C stone oven' },
    { title: 'Quality Check & Boxed Hot', desc: 'Sealed with steam vents & dips' },
    {
      title: order.deliveryType === 'delivery' ? 'Out for Delivery' : 'Ready at Counter / Window',
      desc: order.deliveryType === 'delivery' ? 'Rider on the way to your address' : 'Collect your hot box at Shimla Plaza',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-lg overflow-hidden text-white shadow-2xl relative">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-red-600 via-amber-600 to-amber-500 p-6 text-zinc-950 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-black/20 hover:bg-black/30 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider bg-black/20 text-white px-3 py-1 rounded-full w-fit mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" /> Live Order Tracker
          </div>
          <h3 className="text-2xl font-black tracking-tight text-white">Order #{order.id}</h3>
          <p className="text-xs text-amber-100 font-semibold mt-0.5">
            PizzaBurg Khulna • {order.customerName} ({order.customerPhone})
          </p>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Estimated Time Badge */}
          <div className="bg-zinc-950 border border-amber-500/30 rounded-2xl p-4 flex items-center justify-between text-left shadow-inner">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-extrabold text-xl">
                <Clock className="w-6 h-6 animate-spin text-amber-400" />
              </div>
              <div>
                <div className="text-[11px] text-zinc-400 uppercase font-bold">Estimated Time Remaining</div>
                <div className="text-lg font-black text-amber-400">~{minutesLeft} Minutes</div>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2.5 py-1 rounded-full font-extrabold uppercase">
                {order.deliveryType}
              </span>
            </div>
          </div>

          {/* Stepper Progress */}
          <div className="space-y-4 relative">
            <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-zinc-800"></div>

            {stepsList.map((s, idx) => {
              const isCompleted = idx < step;
              const isCurrent = idx === step;

              return (
                <div key={idx} className="relative flex items-start gap-4 z-10 pl-1">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center font-black text-xs shrink-0 transition-all ${
                      isCompleted
                        ? 'bg-emerald-500 text-zinc-950 shadow-md shadow-emerald-900/40'
                        : isCurrent
                        ? 'bg-amber-500 text-zinc-950 ring-4 ring-amber-500/20 animate-pulse'
                        : 'bg-zinc-800 text-zinc-500'
                    }`}
                  >
                    {isCompleted ? <CheckCircle className="w-4 h-4" /> : idx + 1}
                  </div>
                  <div>
                    <div
                      className={`text-xs font-bold ${
                        isCurrent
                          ? 'text-amber-400 font-extrabold text-sm'
                          : isCompleted
                          ? 'text-emerald-400'
                          : 'text-zinc-500'
                      }`}
                    >
                      {s.title}
                    </div>
                    <div className="text-[11px] text-zinc-400">{s.desc}</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Location & Call Store */}
          <div className="pt-4 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-1.5 text-zinc-400">
              <MapPin className="w-4 h-4 text-red-500 shrink-0" />
              <span>12 KDA Ave, Shimla Plaza, Khulna</span>
            </div>
            <a
              href="tel:01404461257"
              className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 shrink-0"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Kitchen 01404-461257</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
