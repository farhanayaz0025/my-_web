import React, { useState, useMemo } from 'react';
import { Search, Flame, Star, Sparkles, Filter, Plus, ChevronRight, Check } from 'lucide-react';
import { MenuItem, Category, CartItem } from '../types';
import { MENU_ITEMS } from '../data/menuData';
import { ItemModal } from './ItemModal';

interface MenuSectionProps {
  onAddToCart: (cartItem: CartItem) => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [onlySpicy, setOnlySpicy] = useState(false);
  const [onlyVeg, setOnlyVeg] = useState(false);
  const [onlyPopular, setOnlyPopular] = useState(false);
  const [selectedItemForModal, setSelectedItemForModal] = useState<MenuItem | null>(null);

  const categories: { id: Category; label: string; icon: string } = [
    { id: 'all', label: 'All Categories', icon: '🍕' },
    { id: 'pizzas', label: 'Signature Pizzas', icon: '🍕' },
    { id: 'burgers', label: 'Burgers & Smash', icon: '🍔' },
    { id: 'sides', label: 'Sides & Wings', icon: '🍗' },
    { id: 'pasta', label: 'Pasta & Lasagna', icon: '🍝' },
    { id: 'combos', label: 'Student & Value Combos', icon: '🎁' },
    { id: 'drinks', label: 'Drinks & Lava Cake', icon: '🥤' },
  ];

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter((item) => {
      // Category match
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      // Search match
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(query);
        const matchBangla = item.banglaName?.toLowerCase().includes(query);
        const matchDesc = item.description.toLowerCase().includes(query);
        const matchTags = item.tags.some((t) => t.toLowerCase().includes(query));
        if (!matchName && !matchBangla && !matchDesc && !matchTags) return false;
      }
      // Filter toggles
      if (onlySpicy && !item.isSpicy) return false;
      if (onlyVeg && !item.isVegetarian) return false;
      if (onlyPopular && !item.isPopular) return false;

      return true;
    });
  }, [selectedCategory, searchQuery, onlySpicy, onlyVeg, onlyPopular]);

  const handleQuickAdd = (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    if (item.category === 'pizzas') {
      // Open modal so user can pick size & crust
      setSelectedItemForModal(item);
    } else {
      // Direct add
      const cartItem: CartItem = {
        cartId: `${item.id}-${Date.now()}`,
        menuItem: item,
        quantity: 1,
        calculatedUnitPrice: item.basePrice,
      };
      onAddToCart(cartItem);
    }
  };

  return (
    <section id="menu" className="py-12 bg-zinc-950 text-white border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full mb-2">
              PizzaBurg Khulna Menu
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Freshly Baked <span className="text-red-500">Delicious Meals</span>
            </h2>
            <p className="text-sm text-zinc-400 mt-1">
              Select from our 100% Mozzarella handcrafted pizzas, smash burgers, and oven-baked combos.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search pizza, burger, pasta..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-500 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Category Navigation Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-2 shrink-0 ${
                  isActive
                    ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-lg shadow-red-900/30'
                    : 'bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-700'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Toggle Filters */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-zinc-500 flex items-center gap-1 mr-2 font-semibold">
            <Filter className="w-3.5 h-3.5" /> Filters:
          </span>

          <button
            onClick={() => setOnlyPopular(!onlyPopular)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all flex items-center gap-1.5 ${
              onlyPopular
                ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
            Most Popular
          </button>

          <button
            onClick={() => setOnlySpicy(!onlySpicy)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all flex items-center gap-1.5 ${
              onlySpicy
                ? 'bg-red-500/20 border-red-500 text-red-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Flame className="w-3 h-3 text-red-500 fill-red-500" />
            Spicy Items
          </button>

          <button
            onClick={() => setOnlyVeg(!onlyVeg)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-all flex items-center gap-1.5 ${
              onlyVeg
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            Vegetarian
          </button>
        </div>

        {/* Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-zinc-900/50 rounded-3xl border border-zinc-800/80 space-y-3">
            <p className="text-lg font-bold text-zinc-300">No items match your search criteria</p>
            <p className="text-xs text-zinc-500">Try clearing filters or search for another delicious item.</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
                setOnlySpicy(false);
                setOnlyVeg(false);
                setOnlyPopular(false);
              }}
              className="bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItemForModal(item)}
                className="group bg-zinc-900/90 border border-zinc-800/90 hover:border-amber-500/50 rounded-3xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-red-950/30 flex flex-col justify-between cursor-pointer"
              >
                <div>
                  {/* Card Image */}
                  <div className="relative h-48 overflow-hidden bg-zinc-950">
                    <img
                      src={item.image}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />

                    {/* Tag Badges */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                      {item.isPopular && (
                        <span className="bg-gradient-to-r from-amber-500 to-amber-600 text-zinc-950 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow">
                          ★ POPULAR
                        </span>
                      )}
                      {item.isSpicy && (
                        <span className="bg-red-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 shadow">
                          <Flame className="w-2.5 h-2.5" /> SPICY
                        </span>
                      )}
                    </div>

                    <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-black text-amber-400 border border-amber-500/20">
                      ৳{item.basePrice}
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-5 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-extrabold text-base text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                        {item.name}
                      </h3>
                      <div className="flex items-center gap-1 text-xs text-amber-400 font-bold shrink-0">
                        <Star className="w-3 h-3 fill-amber-400" />
                        {item.rating}
                      </div>
                    </div>

                    {item.banglaName && (
                      <p className="text-xs text-amber-500/90 font-medium">{item.banglaName}</p>
                    )}

                    <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">{item.description}</p>
                  </div>
                </div>

                {/* Card Footer */}
                <div className="p-5 pt-0 flex items-center justify-between border-t border-zinc-800/50 mt-2">
                  <span className="text-[11px] text-zinc-500 font-medium">
                    {item.category === 'pizzas' ? 'Select size & crust' : 'Quick add to cart'}
                  </span>
                  <button
                    onClick={(e) => handleQuickAdd(e, item)}
                    className="bg-zinc-800 hover:bg-gradient-to-r hover:from-red-600 hover:to-amber-600 text-white p-2 rounded-xl transition-all flex items-center gap-1 text-xs font-bold"
                  >
                    <span>{item.category === 'pizzas' ? 'Options' : 'Add'}</span>
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Item Customization Modal */}
      <ItemModal
        item={selectedItemForModal}
        onClose={() => setSelectedItemForModal(null)}
        onAddToCart={onAddToCart}
      />
    </section>
  );
};
