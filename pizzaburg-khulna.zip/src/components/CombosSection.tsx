import React from 'react';
import { Gift, Sparkles, CheckCircle, ArrowRight, Plus } from 'lucide-react';
import { CartItem, MenuItem } from '../types';
import { MENU_ITEMS } from '../data/menuData';

interface CombosSectionProps {
  onAddToCart: (cartItem: CartItem) => void;
}

export const CombosSection: React.FC<CombosSectionProps> = ({ onAddToCart }) => {
  const combos = MENU_ITEMS.filter((item) => item.category === 'combos');

  const handleAddCombo = (combo: MenuItem) => {
    const cartItem: CartItem = {
      cartId: `combo-${combo.id}-${Date.now()}`,
      menuItem: combo,
      quantity: 1,
      calculatedUnitPrice: combo.basePrice,
    };
    onAddToCart(cartItem);
  };

  return (
    <section id="combos" className="py-12 bg-gradient-to-b from-zinc-950 via-zinc-900 to-zinc-950 text-white border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3.5 py-1 rounded-full">
            <Gift className="w-3.5 h-3.5 text-amber-400" /> Value Combo Boxes & Deals
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            PizzaBurg <span className="text-amber-400">Khulna Value Feasts</span>
          </h2>
          <p className="text-sm text-zinc-300">
            Enjoy maximum savings with our handcrafted combo packages, designed for students, couples, and family celebrations!
          </p>
        </div>

        {/* Combos Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {combos.map((combo) => (
            <div
              key={combo.id}
              className="bg-zinc-950 border border-zinc-800 hover:border-amber-500/60 rounded-3xl p-6 flex flex-col justify-between space-y-5 transition-all shadow-xl hover:shadow-2xl relative overflow-hidden group"
            >
              <div className="space-y-4">
                {/* Image Banner */}
                <div className="relative h-44 rounded-2xl overflow-hidden bg-zinc-900">
                  <img
                    src={combo.image}
                    alt={combo.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 bg-red-600 text-white text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider">
                    {combo.tags[0] || 'BEST VALUE'}
                  </div>
                  <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md text-amber-400 font-extrabold text-sm px-3 py-1 rounded-full border border-amber-500/30">
                    ৳{combo.basePrice}
                  </div>
                </div>

                <div>
                  <h3 className="font-extrabold text-lg text-white group-hover:text-amber-400 transition-colors">
                    {combo.name}
                  </h3>
                  {combo.banglaName && (
                    <p className="text-xs text-amber-500 font-medium">{combo.banglaName}</p>
                  )}
                  <p className="text-xs text-zinc-300 mt-2 leading-relaxed">{combo.description}</p>
                </div>
              </div>

              {/* Add Combo Button */}
              <button
                onClick={() => handleAddCombo(combo)}
                className="w-full bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold py-3 px-4 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 text-xs"
              >
                <span>Add Combo Box to Cart (৳{combo.basePrice})</span>
                <Plus className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
