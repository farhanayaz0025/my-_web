import React, { useState } from 'react';
import { Star, MessageSquarePlus, ThumbsUp, CheckCircle, User, Send, Filter } from 'lucide-react';
import { Review } from '../types';
import { REVIEWS_DATA } from '../data/reviewsData';

export const ReviewsSection: React.FC = () => {
  const [reviewsList, setReviewsList] = useState<Review[]>(REVIEWS_DATA);
  const [showAddForm, setShowAddForm] = useState(false);

  // New review form states
  const [newAuthor, setNewAuthor] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [newRecommendedItem, setNewRecommendedItem] = useState('PizzaBurg Special');
  const [newOrderType, setNewOrderType] = useState('Dine-in');
  const [newLocation, setNewLocation] = useState('Khulna');

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    const createdReview: Review = {
      id: `rev-${Date.now()}`,
      author: newAuthor.trim(),
      rating: newRating,
      date: 'Just now',
      comment: newComment.trim(),
      recommendedItem: newRecommendedItem.trim() || undefined,
      orderType: newOrderType,
      location: newLocation.trim() || 'Khulna',
      verified: true,
    };

    setReviewsList([createdReview, ...reviewsList]);
    setNewAuthor('');
    setNewComment('');
    setShowAddForm(false);
  };

  return (
    <section id="reviews" className="py-12 bg-zinc-900/80 text-white border-t border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3.5 py-1 rounded-full mb-2">
              Google Maps Rating & Feedback
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Customer <span className="text-amber-400">Loved in Khulna</span>
            </h2>
            <p className="text-sm text-zinc-300">
              Rated <strong className="text-amber-400">4.9 Stars out of 5</strong> by 1,926+ pizza enthusiasts across Khulna.
            </p>
          </div>

          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold px-5 py-3 rounded-2xl shadow-lg transition-all flex items-center gap-2 text-xs shrink-0"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>Write a Customer Review</span>
          </button>
        </div>

        {/* Rating Overview Card */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center bg-zinc-950 border border-zinc-800 rounded-3xl p-6 shadow-xl">
          <div className="md:col-span-4 text-center md:text-left border-b md:border-b-0 md:border-r border-zinc-800 pb-6 md:pb-0 md:pr-6 space-y-2">
            <div className="text-5xl font-black text-amber-400 tracking-tight">4.9</div>
            <div className="flex items-center justify-center md:justify-start gap-1 text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-amber-400" />
              ))}
            </div>
            <p className="text-xs text-zinc-400 font-medium">Based on 1,926 ratings on Google Maps & foodpanda</p>
          </div>

          <div className="md:col-span-8 space-y-2 text-xs">
            {[
              { stars: 5, pct: '92%', count: 1772 },
              { stars: 4, pct: '6%', count: 115 },
              { stars: 3, pct: '1%', count: 20 },
              { stars: 2, pct: '0.5%', count: 10 },
              { stars: 1, pct: '0.5%', count: 9 },
            ].map((row) => (
              <div key={row.stars} className="flex items-center gap-3">
                <span className="w-12 text-zinc-400 font-bold flex items-center gap-1">
                  {row.stars} <Star className="w-3 h-3 fill-zinc-500" />
                </span>
                <div className="flex-1 h-2 bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: row.pct }}></div>
                </div>
                <span className="w-12 text-right text-zinc-500 font-mono text-[11px]">{row.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Write Review Form Collapsible */}
        {showAddForm && (
          <form
            onSubmit={handleAddReview}
            className="bg-zinc-950 border border-amber-500/40 rounded-3xl p-6 space-y-4 animate-in fade-in duration-300"
          >
            <h3 className="font-extrabold text-base text-amber-400">Share Your Experience at PizzaBurg Khulna</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="e.g. Farhan Chowdhury"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      type="button"
                      key={star}
                      onClick={() => setNewRating(star)}
                      className="p-1 hover:scale-110 transition-transform"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= newRating ? 'text-amber-400 fill-amber-400' : 'text-zinc-700'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Your Review Comment *</label>
              <textarea
                rows={3}
                required
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Tell us how you enjoyed the pizza, cheese crust, or service..."
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 resize-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Favorite Item</label>
                <input
                  type="text"
                  value={newRecommendedItem}
                  onChange={(e) => setNewRecommendedItem(e.target.value)}
                  placeholder="e.g. PizzaBurg Special"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Order Type</label>
                <select
                  value={newOrderType}
                  onChange={(e) => setNewOrderType(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white"
                >
                  <option value="Dine-in">Dine-in</option>
                  <option value="Delivery">Delivery</option>
                  <option value="Takeaway">Takeaway</option>
                  <option value="Drive-through">Drive-through</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Your Area in Khulna</label>
                <input
                  type="text"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  placeholder="e.g. Sonadanga"
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold text-xs px-6 py-2.5 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Submit Review</span>
            </button>
          </form>
        )}

        {/* Reviews List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviewsList.map((rev) => (
            <div
              key={rev.id}
              className="bg-zinc-950 border border-zinc-800/80 rounded-3xl p-5 space-y-3 flex flex-col justify-between shadow-lg"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-600 to-amber-500 text-white font-extrabold text-xs flex items-center justify-center">
                      {rev.author.charAt(0)}
                    </div>
                    <div>
                      <div className="font-extrabold text-xs text-white flex items-center gap-1">
                        {rev.author}
                        {rev.verified && <CheckCircle className="w-3 h-3 text-emerald-400" />}
                      </div>
                      <div className="text-[10px] text-zinc-500">
                        {rev.location} • {rev.orderType}
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] text-zinc-500">{rev.date}</span>
                </div>

                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>

                <p className="text-xs text-zinc-300 leading-relaxed italic">"{rev.comment}"</p>
              </div>

              {rev.recommendedItem && (
                <div className="pt-2 border-t border-zinc-900 text-[11px] text-amber-400 font-semibold">
                  Recommended: {rev.recommendedItem}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
