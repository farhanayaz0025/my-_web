import React, { useState } from 'react';
import { X, Plus, Minus, ShoppingBag, Flame, Check, AlertCircle } from 'lucide-react';
import { MenuItem, PizzaSize, PizzaCrust, Topping, CartItem } from '../types';
import { TOPPINGS_LIST } from '../data/menuData';

interface ItemModalProps {
  item: MenuItem | null;
  onClose: () => void;
  onAddToCart: (cartItem: CartItem) => void;
}

export const ItemModal: React.FC<ItemModalProps> = ({ item, onClose, onAddToCart }) => {
  if (!item) return null;

  const isPizza = item.category === 'pizzas' && item.sizes && item.sizes.length > 0;

  const [selectedSize, setSelectedSize] = useState<PizzaSize>(
    isPizza && item.sizes ? item.sizes[0].name : '8" Personal'
  );

  const [selectedCrust, setSelectedCrust] = useState<PizzaCrust>(
    isPizza && item.crusts ? item.crusts[0].name : 'Regular Pan'
  );

  const [selectedToppings, setSelectedToppings] = useState<Topping[]>([]);
  const [quantity, setQuantity] = useState<number>(1);
  const [specialInstructions, setSpecialInstructions] = useState<string>('');

  // Price Calculation Logic
  let unitPrice = item.basePrice;

  if (isPizza && item.sizes) {
    const sizeOpt = item.sizes.find((s) => s.name === selectedSize);
    if (sizeOpt) {
      unitPrice = Math.round(item.basePrice * sizeOpt.priceModifier);
    }
    if (item.crusts) {
      const crustOpt = item.crusts.find((c) => c.name === selectedCrust);
      if (crustOpt) {
        unitPrice += crustOpt.additionalCost;
      }
    }
  }

  const toppingsTotalPrice = selectedToppings.reduce((sum, t) => sum + t.price, 0);
  const finalUnitPrice = unitPrice + toppingsTotalPrice;
  const totalPrice = finalUnitPrice * quantity;

  const toggleTopping = (topping: Topping) => {
    if (selectedToppings.some((t) => t.id === topping.id)) {
      setSelectedToppings(selectedToppings.filter((t) => t.id !== topping.id));
    } else {
      setSelectedToppings([...selectedToppings, topping]);
    }
  };

  const handleAdd = () => {
    const cartItem: CartItem = {
      cartId: `${item.id}-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      menuItem: item,
      selectedSize: isPizza ? selectedSize : undefined,
      selectedCrust: isPizza ? selectedCrust : undefined,
      customToppings: selectedToppings,
      quantity,
      calculatedUnitPrice: finalUnitPrice,
      specialInstructions: specialInstructions.trim() || undefined,
    };

    onAddToCart(cartItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto text-white shadow-2xl relative flex flex-col">
        {/* Sticky Header with Close Button */}
        <div className="sticky top-0 z-10 bg-zinc-900/95 backdrop-blur-md px-6 py-4 border-b border-zinc-800 flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-xl text-white flex items-center gap-2">
              {item.name}
              {item.isSpicy && <Flame className="w-4 h-4 text-red-500 fill-red-500" />}
            </h3>
            {item.banglaName && <p className="text-xs text-amber-400 font-medium">{item.banglaName}</p>}
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6">
          {/* Item Image Banner */}
          <div className="relative h-48 sm:h-56 rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950">
            <img
              src={item.image}
              alt={item.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-amber-400 border border-amber-500/30">
              Starting BDT ৳{item.basePrice}
            </div>
            {item.prepTimeMinutes && (
              <div className="absolute top-3 right-3 bg-zinc-900/90 backdrop-blur-md px-2.5 py-1 rounded-full text-[11px] font-semibold text-zinc-300 border border-zinc-700">
                Prep: ~{item.prepTimeMinutes} mins
              </div>
            )}
          </div>

          <p className="text-sm text-zinc-300 leading-relaxed">{item.description}</p>

          {/* Pizza Size Selection */}
          {isPizza && item.sizes && (
            <div className="space-y-3">
              <label className="block text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                1. Select Size
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {item.sizes.map((size) => {
                  const calculated = Math.round(item.basePrice * size.priceModifier);
                  const isSelected = selectedSize === size.name;
                  return (
                    <button
                      key={size.name}
                      onClick={() => setSelectedSize(size.name)}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'bg-gradient-to-br from-red-600/30 to-amber-600/30 border-amber-500 text-white shadow-lg'
                          : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700 text-zinc-300'
                      }`}
                    >
                      <div className="font-bold text-xs">{size.name}</div>
                      <div className="text-[10px] text-zinc-400 line-clamp-1">{size.description}</div>
                      <div className="mt-1 font-extrabold text-amber-400 text-xs">৳{calculated}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Pizza Crust Selection */}
          {isPizza && item.crusts && (
            <div className="space-y-3">
              <label className="block text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                2. Select Crust
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {item.crusts.map((crust) => {
                  const isSelected = selectedCrust === crust.name;
                  return (
                    <button
                      key={crust.name}
                      onClick={() => setSelectedCrust(crust.name)}
                      className={`p-3 rounded-2xl border text-left transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-red-950/50 border-red-500 text-white'
                          : 'bg-zinc-950 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-xs">{crust.name}</div>
                        {crust.additionalCost > 0 ? (
                          <div className="text-[10px] text-amber-400 font-semibold">+৳{crust.additionalCost}</div>
                        ) : (
                          <div className="text-[10px] text-zinc-500">Included</div>
                        )}
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-red-500" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Extra Topping Selection */}
          <div className="space-y-3">
            <label className="block text-xs uppercase font-extrabold text-amber-400 tracking-wider">
              {isPizza ? '3. Customize Extra Toppings (Optional)' : 'Add Extra Sides & Cheese'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {TOPPINGS_LIST.map((topping) => {
                const isChecked = selectedToppings.some((t) => t.id === topping.id);
                return (
                  <button
                    key={topping.id}
                    onClick={() => toggleTopping(topping)}
                    className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                      isChecked
                        ? 'bg-amber-500/20 border-amber-500 text-amber-200'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <div>
                      <div className="font-medium">{topping.name}</div>
                      <div className="text-[10px] font-bold text-amber-400">+৳{topping.price}</div>
                    </div>
                    {isChecked && <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Special Instructions Note */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-zinc-400">
              Special Instructions (e.g., extra spicy, no onions, extra sauce)
            </label>
            <input
              type="text"
              value={specialInstructions}
              onChange={(e) => setSpecialInstructions(e.target.value)}
              placeholder="Add notes for PizzaBurg chef..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="sticky bottom-0 bg-zinc-950/95 backdrop-blur-md px-6 py-4 border-t border-zinc-800 flex flex-wrap items-center justify-between gap-4">
          {/* Quantity Selector */}
          <div className="flex items-center gap-3 bg-zinc-900 border border-zinc-800 rounded-xl p-1">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-300"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="font-extrabold text-sm w-6 text-center">{quantity}</span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="w-8 h-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-300"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Price & Add to Cart Button */}
          <button
            onClick={handleAdd}
            className="flex-1 bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold py-3 px-6 rounded-2xl shadow-xl flex items-center justify-between text-sm transition-all"
          >
            <span className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4" />
              Add to Order
            </span>
            <span className="bg-black/30 px-3 py-1 rounded-xl text-amber-200 font-black">
              ৳{totalPrice}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
