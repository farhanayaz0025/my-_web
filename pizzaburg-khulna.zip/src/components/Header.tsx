import React, { useState } from 'react';
import { ShoppingBag, MapPin, Phone, Clock, Sparkles, Star, Menu as MenuIcon, X, ExternalLink } from 'lucide-react';
import { CartItem } from '../types';

interface HeaderProps {
  cartItems: CartItem[];
  onOpenCart: () => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartItems,
  onOpenCart,
  activeSection,
  setActiveSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalCartPrice = cartItems.reduce((acc, item) => acc + item.calculatedUnitPrice * item.quantity, 0);

  const navLinks = [
    { id: 'menu', label: 'Full Menu' },
    { id: 'customizer', label: 'Build Your Pizza' },
    { id: 'ai-assistant', label: 'AI Craving Assistant', badge: 'Smart AI' },
    { id: 'combos', label: 'Deals & Combos' },
    { id: 'reviews', label: 'Reviews (4.9 ★)' },
    { id: 'location', label: 'Location & Hours' },
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800/80 text-white shadow-xl">
      {/* Top Banner Bar with Khulna Info */}
      <div className="bg-gradient-to-r from-red-700 via-red-600 to-amber-600 px-4 py-1.5 text-xs text-amber-50 font-medium">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-semibold">
              <MapPin className="w-3.5 h-3.5 text-amber-200" />
              12 KDA Ave, Shimla Plaza, Khulna 9100
            </span>
            <span className="hidden md:inline text-red-200">•</span>
            <span className="hidden md:flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-200" />
              Open Daily: 11:00 AM – 11:00 PM
            </span>
            <span className="hidden lg:inline text-red-200">•</span>
            <span className="hidden lg:flex items-center gap-1 bg-black/20 px-2 py-0.5 rounded-full text-[11px]">
              <Star className="w-3 h-3 text-amber-300 fill-amber-300" />
              4.9 Rating (1,926 Reviews)
            </span>
          </div>

          <div className="flex items-center gap-3 ml-auto">
            <a
              href="tel:01404461257"
              className="flex items-center gap-1 hover:text-white transition-colors bg-white/10 px-2.5 py-0.5 rounded-full text-[11px]"
            >
              <Phone className="w-3 h-3 text-amber-200" />
              01404-461257
            </a>
            <a
              href="https://www.foodpanda.com.bd"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:bg-pink-600 bg-pink-700 text-white px-2.5 py-0.5 rounded-full text-[11px] font-semibold transition-colors"
            >
              foodpanda
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <button
          onClick={() => handleNavClick('hero')}
          className="flex items-center gap-3 text-left group focus:outline-none"
        >
          <div className="relative">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-red-600 to-amber-500 p-0.5 shadow-lg shadow-red-900/30 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-zinc-900 rounded-[14px] flex items-center justify-center font-black text-2xl tracking-tighter text-amber-400">
                P<span className="text-red-500">B</span>
              </div>
            </div>
            <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xl tracking-tight text-white group-hover:text-amber-400 transition-colors">
                PIZZA<span className="text-red-500">BURG</span>
              </span>
              <span className="text-[10px] bg-red-950 text-red-400 border border-red-800/80 px-1.5 py-0.2 rounded uppercase font-semibold tracking-wider">
                Khulna
              </span>
            </div>
            <p className="text-xs text-zinc-400 font-medium">12 KDA Ave • Shimla Plaza</p>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 bg-zinc-900/90 p-1.5 rounded-full border border-zinc-800">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`relative px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-md'
                    : 'text-zinc-300 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <span className="flex items-center gap-1.5">
                  {link.badge && (
                    <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
                  )}
                  {link.label}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Call Button (Mobile & Desktop) */}
          <a
            href="tel:01404461257"
            className="hidden sm:flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 px-3 py-2 rounded-xl text-xs font-medium transition-colors"
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>Call Us</span>
          </a>

          {/* Cart Drawer Toggle Button */}
          <button
            onClick={onOpenCart}
            className="relative bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white px-3.5 sm:px-4 py-2 rounded-xl flex items-center gap-2.5 shadow-lg shadow-red-900/40 hover:shadow-red-800/60 transition-all focus:outline-none"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              {totalCartCount > 0 && (
                <span className="absolute -top-2.5 -right-2.5 bg-zinc-950 text-amber-400 text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center border-2 border-red-500 animate-bounce">
                  {totalCartCount}
                </span>
              )}
            </div>
            <div className="text-left hidden xs:block">
              <div className="text-[10px] uppercase font-bold text-amber-200 leading-tight">Order Cart</div>
              <div className="text-xs font-black tracking-tight">
                {totalCartPrice > 0 ? `৳${totalCartPrice}` : 'Empty'}
              </div>
            </div>
          </button>

          {/* Mobile Navigation Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden bg-zinc-900 hover:bg-zinc-800 text-zinc-300 p-2 rounded-xl border border-zinc-800 focus:outline-none"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-zinc-900 border-b border-zinc-800 px-4 py-4 space-y-2 text-sm animate-in slide-in-from-top-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-left font-medium transition-colors ${
                activeSection === link.id
                  ? 'bg-gradient-to-r from-red-600 to-amber-600 text-white font-semibold'
                  : 'text-zinc-300 hover:bg-zinc-800'
              }`}
            >
              <span>{link.label}</span>
              {link.badge && (
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full font-bold">
                  {link.badge}
                </span>
              )}
            </button>
          ))}
          <div className="pt-2 border-t border-zinc-800 flex items-center gap-2">
            <a
              href="tel:01404461257"
              className="flex-1 flex items-center justify-center gap-2 bg-zinc-800 text-white py-2.5 rounded-xl font-medium text-xs"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              Call 01404-461257
            </a>
            <a
              href="https://www.foodpanda.com.bd"
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-1.5 bg-pink-700 text-white py-2.5 rounded-xl font-medium text-xs"
            >
              <span>Order on foodpanda</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
