export type Category = 'all' | 'pizzas' | 'burgers' | 'sides' | 'pasta' | 'combos' | 'drinks';

export type PizzaSize = '8" Personal' | '10" Medium' | '12" Large' | '14" Family';
export type PizzaCrust = 'Regular Pan' | 'Thin & Crispy' | 'Cheesy Stuffed Crust' | 'Garlic Butter Crust';
export type DeliveryType = 'delivery' | 'pickup' | 'dinein' | 'drivethru';

export interface SizeOption {
  name: PizzaSize;
  priceModifier: number; //Multiplier or added BDT
  description: string;
}

export interface CrustOption {
  name: PizzaCrust;
  additionalCost: number; // in BDT
}

export interface MenuItem {
  id: string;
  name: string;
  banglaName?: string;
  description: string;
  category: Category;
  basePrice: number; // BDT
  image: string;
  rating: number;
  reviewsCount: number;
  isSpicy?: boolean;
  isPopular?: boolean;
  isVegetarian?: boolean;
  tags: string[];
  sizes?: SizeOption[];
  crusts?: CrustOption[];
  prepTimeMinutes?: number;
}

export interface Topping {
  id: string;
  name: string;
  category: 'meat' | 'veggie' | 'cheese' | 'sauce';
  price: number; // BDT
  image?: string;
}

export interface CartItem {
  cartId: string;
  menuItem: MenuItem;
  selectedSize?: PizzaSize;
  selectedCrust?: PizzaCrust;
  customToppings?: Topping[];
  quantity: number;
  calculatedUnitPrice: number;
  specialInstructions?: string;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  recommendedItem?: string;
  orderType?: string;
  location?: string;
  verified: boolean;
}

export interface Order {
  id: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  totalAmount: number;
  deliveryType: DeliveryType;
  customerName: string;
  customerPhone: string;
  deliveryAddress?: string;
  tableNumber?: string;
  vehicleNumber?: string;
  paymentMethod: 'cash' | 'bkash' | 'nagad' | 'card';
  status: 'received' | 'preparing' | 'baking' | 'delivering' | 'ready';
  createdAt: string;
  estimatedMinutes: number;
}

export interface AIRecommendationRequest {
  peopleCount: number;
  budgetBDT: number;
  preferences: string;
  spicyLevel?: 'mild' | 'medium' | 'extra_spicy';
  dietary?: string;
}

export interface AIRecommendationResponse {
  suggestionTitle: string;
  explanation: string;
  suggestedItems: {
    itemId: string;
    itemName: string;
    size?: PizzaSize;
    quantity: number;
    price: number;
    reason: string;
  }[];
  totalEstimatedCost: number;
  savingsTip?: string;
}
