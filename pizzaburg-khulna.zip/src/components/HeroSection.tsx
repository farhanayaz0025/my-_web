import React from 'react';
import { Star, Flame, ShoppingBag, MapPin, Sparkles, ShieldCheck, Clock, Navigation } from 'lucide-react';

interface HeroSectionProps {
  onOrderNow: () => void;
  onOpenCustomizer: () => void;
  onOpenAI: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOrderNow,
  onOpenCustomizer,
  onOpenAI,
}) => {
  return (
    <section id="hero" className="relative bg-zinc-950 overflow-hidden text-white pt-6 pb-12 lg:py-16">
      {/* Background Subtle Gradient Blobs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-red-600/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Rating & Location Badge */}
            <div className="inline-flex flex-wrap items-center gap-2 bg-zinc-900/90 border border-zinc-800 p-1.5 pr-4 rounded-full text-xs">
              <span className="flex items-center gap-1 bg-gradient-to-r from-amber-500 to-amber-600 text-zinc-950 px-2.5 py-1 rounded-full font-bold shadow-sm">
                <Star className="w-3.5 h-3.5 fill-zinc-950" />
                4.9 / 5.0
              </span>
              <span className="text-zinc-300 font-semibold">(1,926 Verified Reviews)</span>
              <span className="text-zinc-600">•</span>
              <span className="text-amber-400 font-medium">৳200–400 per person</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-none text-white">
              Khulna's Favorite <br />
              <span className="bg-gradient-to-r from-red-500 via-amber-400 to-amber-200 bg-clip-text text-transparent">
                Hot & Cheesy Pizza
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-zinc-300 max-w-2xl leading-relaxed">
              Baked daily with 100% real mozzarella, signature spicy marinara sauce, and premium halal meats. Visit us at <strong className="text-amber-400 font-semibold">Shimla Plaza, 12 KDA Ave, Khulna</strong> or order hot to your doorstep!
            </p>

            {/* Service Capabilities Pills */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-zinc-300">
              <span className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-emerald-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                100% Halal
              </span>
              <span className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-amber-400">
                <Flame className="w-4 h-4 text-amber-400" />
                Stone Oven Baked
              </span>
              <span className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-lg text-sky-400">
                <Clock className="w-4 h-4 text-sky-400" />
                Dine-in • Drive-thru • Delivery
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onOrderNow}
                className="bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold px-6 py-3.5 rounded-2xl shadow-xl shadow-red-900/40 hover:shadow-red-800/60 transition-all transform hover:-translate-y-0.5 flex items-center gap-2 text-sm sm:text-base"
              >
                <ShoppingBag className="w-5 h-5" />
                <span>Explore Full Menu & Order</span>
              </button>

              <button
                onClick={onOpenCustomizer}
                className="bg-zinc-900 hover:bg-zinc-800 text-amber-300 border border-amber-500/40 font-bold px-5 py-3.5 rounded-2xl transition-all flex items-center gap-2 text-sm sm:text-base"
              >
                <Flame className="w-4 h-4 text-amber-400" />
                <span>Build Custom Pizza</span>
              </button>

              <button
                onClick={onOpenAI}
                className="bg-gradient-to-r from-purple-900/80 to-zinc-900 hover:from-purple-800 text-purple-200 border border-purple-500/40 font-bold px-4 py-3.5 rounded-2xl transition-all flex items-center gap-2 text-xs sm:text-sm"
              >
                <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
                <span>AI Meal Finder</span>
              </button>
            </div>

            {/* Address & Quick Directions link */}
            <div className="pt-4 border-t border-zinc-800/80 flex items-center gap-3 text-xs text-zinc-400">
              <MapPin className="w-4 h-4 text-red-500 shrink-0" />
              <span>12 KDA Ave, Khulna 9100 (Shimla Plaza) • Plus Code: RH93+J9</span>
              <a
                href="https://maps.google.com/?q=PizzaBurg+Khulna+12+KDA+Ave+Shimla+Plaza"
                target="_blank"
                rel="noopener noreferrer"
                className="text-amber-400 hover:underline flex items-center gap-1 font-semibold ml-auto"
              >
                <span>Directions</span>
                <Navigation className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Right Visual Image Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer Glow Ring */}
              <div className="absolute -inset-1 bg-gradient-to-r from-red-600 via-amber-500 to-red-600 rounded-3xl blur-xl opacity-40 animate-pulse"></div>

              {/* Main Image Container */}
              <div className="relative rounded-3xl overflow-hidden border-2 border-zinc-800 bg-zinc-900 shadow-2xl">
                <img
                  src="/src/assets/images/pizzaburg_hero_1786541624334.jpg"
                  alt="PizzaBurg Khulna Signature Cheesy Pizza"
                  referrerPolicy="no-referrer"
                  className="w-full h-80 sm:h-96 object-cover transform hover:scale-105 transition-transform duration-700"
                />

                {/* Overlaid Float Cards */}
                <div className="absolute top-4 left-4 bg-zinc-950/90 backdrop-blur-md border border-zinc-800 rounded-2xl p-3 shadow-xl flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                    <Flame className="w-5 h-5 text-amber-400" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">House Special</div>
                    <div className="text-[11px] text-amber-400 font-extrabold">PizzaBurg Special ৳380</div>
                  </div>
                </div>

                <div className="absolute bottom-4 right-4 bg-zinc-950/95 backdrop-blur-md border border-amber-500/30 rounded-2xl p-3 shadow-2xl flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                    4.9★
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">1,926 Customer Reviews</div>
                    <div className="text-[11px] text-emerald-400 font-medium">Khulna's Top Rated Pizza</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
