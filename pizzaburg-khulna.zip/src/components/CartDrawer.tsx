import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, Check, AlertCircle } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (cartId: string, delta: number) => void;
  onRemoveItem: (cartId: string) => void;
  onOpenCheckout: (discountAmount: number, promoCodeUsed: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onOpenCheckout,
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.calculatedUnitPrice * item.quantity,
    0
  );

  const deliveryFee = subtotal > 0 ? 40 : 0;
  const discountAmount = promoApplied ? Math.round(subtotal * 0.1) : 0;
  const grandTotal = Math.max(0, subtotal + deliveryFee - discountAmount);

  const handleApplyPromo = () => {
    const code = promoCode.trim().toUpperCase();
    if (code === 'PIZZABURG10' || code === 'KHULNA10' || code === 'STUDENT10') {
      setPromoApplied(true);
      setPromoError('');
    } else {
      setPromoError('Invalid coupon code. Try "PIZZABURG10" for 10% off!');
      setPromoApplied(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-zinc-950 text-white border-l border-zinc-800 shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/90">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-red-600/20 text-red-500 rounded-xl">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-white">Your PizzaBurg Order</h3>
                <p className="text-xs text-zinc-400">
                  {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} in cart
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="text-center py-20 space-y-4">
                <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 mx-auto flex items-center justify-center text-zinc-500">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="font-bold text-zinc-300 text-base">Your cart is empty</h4>
                <p className="text-xs text-zinc-500 max-w-xs mx-auto">
                  Explore PizzaBurg Khulna menu to add your favorite pizzas, burgers, and garlic bread!
                </p>
                <button
                  onClick={onClose}
                  className="bg-amber-500 hover:bg-amber-400 text-zinc-950 font-extrabold text-xs px-5 py-2.5 rounded-xl transition-colors"
                >
                  Browse Menu
                </button>
              </div>
            ) : (
              cartItems.map((item) => (
                <div
                  key={item.cartId}
                  className="bg-zinc-900/90 border border-zinc-800/80 rounded-2xl p-3.5 space-y-3 relative"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={item.menuItem.image}
                        alt={item.menuItem.name}
                        referrerPolicy="no-referrer"
                        className="w-14 h-14 rounded-xl object-cover border border-zinc-800 shrink-0"
                      />
                      <div>
                        <h4 className="font-extrabold text-xs text-white">{item.menuItem.name}</h4>
                        {item.selectedSize && (
                          <div className="text-[10px] text-amber-400 font-bold">
                            Size: {item.selectedSize} ({item.selectedCrust})
                          </div>
                        )}
                        {item.customToppings && item.customToppings.length > 0 && (
                          <div className="text-[10px] text-zinc-400 line-clamp-1">
                            Toppings: {item.customToppings.map((t) => t.name).join(', ')}
                          </div>
                        )}
                        <div className="text-xs font-black text-amber-300 mt-1">
                          ৳{item.calculatedUnitPrice * item.quantity}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.cartId)}
                      className="text-zinc-500 hover:text-red-400 p-1 transition-colors"
                      title="Remove Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex items-center justify-between border-t border-zinc-800/60 pt-2.5">
                    <span className="text-[10px] text-zinc-500 font-medium">Quantity</span>
                    <div className="flex items-center gap-2 bg-zinc-950 border border-zinc-800 rounded-lg p-0.5">
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, -1)}
                        className="w-6 h-6 rounded bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-300"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-bold text-xs w-5 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, 1)}
                        className="w-6 h-6 rounded bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-300"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Pricing & Checkout */}
          {cartItems.length > 0 && (
            <div className="p-5 border-t border-zinc-800 bg-zinc-900/95 space-y-4">
              {/* Promo code box */}
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="Promo Code (PIZZABURG10)"
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500 uppercase font-mono"
                    />
                  </div>
                  <button
                    onClick={handleApplyPromo}
                    className="bg-zinc-800 hover:bg-zinc-700 text-amber-300 text-xs font-bold px-3 py-2 rounded-xl transition-colors shrink-0"
                  >
                    Apply
                  </button>
                </div>
                {promoApplied && (
                  <p className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3 h-3" /> 10% discount applied! Saved ৳{discountAmount}
                  </p>
                )}
                {promoError && <p className="text-[11px] text-red-400 font-medium">{promoError}</p>}
              </div>

              {/* Subtotal calculations */}
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal:</span>
                  <span className="font-bold text-white">৳{subtotal}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Khulna Local Delivery:</span>
                  <span className="font-bold text-white">৳{deliveryFee}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400 font-bold">
                    <span>Discount (10% Off):</span>
                    <span>-৳{discountAmount}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm font-black text-white">
                  <span>Grand Total:</span>
                  <span className="text-amber-400 text-base">৳{grandTotal}</span>
                </div>
              </div>

              {/* Checkout Trigger */}
              <button
                onClick={() => onOpenCheckout(discountAmount, promoApplied ? 'PIZZABURG10' : '')}
                className="w-full bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl flex items-center justify-between text-sm transition-all"
              >
                <span>Proceed to Checkout</span>
                <div className="flex items-center gap-1">
                  <span className="bg-black/30 px-2.5 py-0.5 rounded-lg text-amber-200">৳{grandTotal}</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
