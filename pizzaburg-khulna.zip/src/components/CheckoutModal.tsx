import React, { useState } from 'react';
import { X, MapPin, Phone, User, CreditCard, ShoppingBag, CheckCircle, Car, Utensils, Bike } from 'lucide-react';
import { CartItem, DeliveryType, Order } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  discountAmount: number;
  promoCodeUsed: string;
  onOrderPlaced: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  discountAmount,
  promoCodeUsed,
  onOrderPlaced,
}) => {
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('delivery');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('Sonadanga, Khulna');
  const [tableNumber, setTableNumber] = useState('Table 4');
  const [vehicleNumber, setVehicleNumber] = useState('Khulna Metro HA-1234');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'bkash' | 'nagad' | 'card'>('bkash');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => sum + item.calculatedUnitPrice * item.quantity, 0);
  const deliveryFee = deliveryType === 'delivery' ? 40 : 0;
  const grandTotal = Math.max(0, subtotal + deliveryFee - discountAmount);

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) {
      setErrorMessage('Please provide your name and valid phone number.');
      return;
    }

    if (deliveryType === 'delivery' && !deliveryAddress.trim()) {
      setErrorMessage('Please provide your Khulna delivery address.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');

    try {
      const response = await fetch('/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cartItems,
          deliveryType,
          customerName,
          customerPhone,
          deliveryAddress: deliveryType === 'delivery' ? deliveryAddress : undefined,
          tableNumber: deliveryType === 'dinein' ? tableNumber : undefined,
          vehicleNumber: deliveryType === 'drivethru' ? vehicleNumber : undefined,
          paymentMethod,
          totalAmount: grandTotal,
        }),
      });

      const resData = await response.json();

      const newOrder: Order = {
        id: resData.orderId || 'PBK-' + Math.floor(100000 + Math.random() * 900000),
        items: cartItems,
        subtotal,
        deliveryFee,
        discount: discountAmount,
        totalAmount: grandTotal,
        deliveryType,
        customerName,
        customerPhone,
        deliveryAddress: deliveryType === 'delivery' ? deliveryAddress : undefined,
        tableNumber: deliveryType === 'dinein' ? tableNumber : undefined,
        vehicleNumber: deliveryType === 'drivethru' ? vehicleNumber : undefined,
        paymentMethod,
        status: 'received',
        createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        estimatedMinutes: deliveryType === 'delivery' ? 30 : 15,
      };

      onOrderPlaced(newOrder);
      onClose();
    } catch (err) {
      console.error(err);
      setErrorMessage('Order placement failed. Please try again or call 01404-461257.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto text-white shadow-2xl relative">
        {/* Header */}
        <div className="sticky top-0 bg-zinc-900/95 backdrop-blur-md px-6 py-4 border-b border-zinc-800 flex items-center justify-between">
          <div>
            <h3 className="font-extrabold text-lg text-white">Complete Your PizzaBurg Order</h3>
            <p className="text-xs text-amber-400">Shimla Plaza, 12 KDA Ave, Khulna</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmitOrder} className="p-6 space-y-6">
          {errorMessage && (
            <div className="p-3 bg-red-950/80 border border-red-800 text-red-300 text-xs rounded-xl font-medium">
              {errorMessage}
            </div>
          )}

          {/* 1. Service Type Selection */}
          <div className="space-y-3">
            <label className="block text-xs uppercase font-extrabold text-amber-400 tracking-wider">
              1. Select Service Option
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'delivery', label: 'Home Delivery', icon: Bike },
                { id: 'dinein', label: 'Dine-in Plaza', icon: Utensils },
                { id: 'drivethru', label: 'Drive-through', icon: Car },
                { id: 'pickup', label: 'Takeaway', icon: ShoppingBag },
              ].map((option) => {
                const Icon = option.icon;
                const isSelected = deliveryType === option.id;
                return (
                  <button
                    type="button"
                    key={option.id}
                    onClick={() => setDeliveryType(option.id as DeliveryType)}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                      isSelected
                        ? 'bg-gradient-to-br from-red-600/40 to-amber-600/40 border-amber-500 text-white font-bold shadow'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isSelected ? 'text-amber-400' : 'text-zinc-500'}`} />
                    <span className="text-xs">{option.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Customer Contact Info */}
          <div className="space-y-3">
            <label className="block text-xs uppercase font-extrabold text-amber-400 tracking-wider">
              2. Your Contact Details
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Full Name *</label>
                <div className="relative">
                  <User className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Tanvir Ahmed"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Mobile Phone *</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="017XXXXXXXX"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            </div>

            {/* Dynamic field depending on delivery type */}
            {deliveryType === 'delivery' && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">
                  Khulna Delivery Address (e.g., Sonadanga, Boyra, KDA Ave) *
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    placeholder="House / Road / Area in Khulna"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}

            {deliveryType === 'dinein' && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Shimla Plaza Table Number</label>
                <input
                  type="text"
                  value={tableNumber}
                  onChange={(e) => setTableNumber(e.target.value)}
                  placeholder="e.g. Table 5"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            )}

            {deliveryType === 'drivethru' && (
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Vehicle Plate / Bike Number</label>
                <input
                  type="text"
                  value={vehicleNumber}
                  onChange={(e) => setVehicleNumber(e.target.value)}
                  placeholder="e.g. Khulna Metro HA-1234"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            )}
          </div>

          {/* 3. Payment Method */}
          <div className="space-y-3">
            <label className="block text-xs uppercase font-extrabold text-amber-400 tracking-wider">
              3. Payment Option
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'bkash', label: 'bKash Mobile', badge: 'Popular' },
                { id: 'nagad', label: 'Nagad Pay' },
                { id: 'cash', label: 'Cash on Delivery' },
                { id: 'card', label: 'Card Payment' },
              ].map((p) => {
                const isSelected = paymentMethod === p.id;
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => setPaymentMethod(p.id as any)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center ${
                      isSelected
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <div>{p.label}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Total Summary Box */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 space-y-1.5 text-xs">
            <div className="flex justify-between text-zinc-400">
              <span>Items Total ({cartItems.length} items):</span>
              <span>৳{subtotal}</span>
            </div>
            {deliveryFee > 0 && (
              <div className="flex justify-between text-zinc-400">
                <span>Khulna Delivery Fee:</span>
                <span>৳{deliveryFee}</span>
              </div>
            )}
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Promo Discount ({promoCodeUsed}):</span>
                <span>-৳{discountAmount}</span>
              </div>
            )}
            <div className="pt-2 border-t border-zinc-800 flex justify-between text-sm font-black text-white">
              <span>Payable Amount:</span>
              <span className="text-amber-400 text-base">৳{grandTotal}</span>
            </div>
          </div>

          {/* Submit Order Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl flex items-center justify-center gap-2 text-sm transition-all disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Sending Order to Oven...</span>
              </>
            ) : (
              <>
                <CheckCircle className="w-5 h-5" />
                <span>Confirm & Place Order (৳{grandTotal})</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
