import React from 'react';
import { MapPin, Phone, Clock, Navigation, ExternalLink, ShieldCheck, Car, Utensils, Bike, Share2, Heart } from 'lucide-react';

export const LocationSection: React.FC = () => {
  return (
    <section id="location" className="py-12 bg-zinc-950 text-white border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3.5 py-1 rounded-full">
            <MapPin className="w-3.5 h-3.5 text-amber-400" /> Visit Us in Khulna
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Location, Hours & <span className="text-amber-400">Directions</span>
          </h2>
          <p className="text-sm text-zinc-300">
            Conveniently situated at Shimla Plaza on KDA Ave. Stop by for dine-in, grab drive-through, or order fast delivery!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Store Info Card */}
          <div className="lg:col-span-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 space-y-6 flex flex-col justify-between shadow-xl">
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest bg-amber-950/80 px-2.5 py-0.5 rounded-full border border-amber-800/60">
                  Shimla Plaza
                </span>
                <h3 className="text-2xl font-black text-white">PizzaBurg Khulna</h3>
                <p className="text-xs text-zinc-400">12 KDA Ave, Khulna 9100 • Plus Code: RH93+J9 Khulna</p>
              </div>

              {/* Ambiance Photo */}
              <div className="relative h-44 rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-950">
                <img
                  src="/src/assets/images/pizzaburg_ambiance_1786541638770.jpg"
                  alt="PizzaBurg Khulna Ambiance"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-3 left-3 text-xs font-bold text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  Open Now • Closes 11:00 PM
                </div>
              </div>

              {/* Service Badges */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-2.5 space-y-1">
                  <Utensils className="w-4 h-4 text-amber-400 mx-auto" />
                  <div className="font-bold text-[11px]">Dine-in</div>
                  <div className="text-[10px] text-zinc-500">Cozy Seating</div>
                </div>
                <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-2.5 space-y-1">
                  <Car className="w-4 h-4 text-amber-400 mx-auto" />
                  <div className="font-bold text-[11px]">Drive-thru</div>
                  <div className="text-[10px] text-zinc-500">Quick Pickup</div>
                </div>
                <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-2.5 space-y-1">
                  <Bike className="w-4 h-4 text-amber-400 mx-auto" />
                  <div className="font-bold text-[11px]">Delivery</div>
                  <div className="text-[10px] text-zinc-500">No-Contact</div>
                </div>
              </div>

              {/* Key Details List */}
              <div className="space-y-3 text-xs border-t border-zinc-800 pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-amber-400" /> Phone Hotline:
                  </span>
                  <a href="tel:01404461257" className="font-extrabold text-amber-300 hover:underline">
                    01404-461257
                  </a>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-zinc-400 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" /> Opening Hours:
                  </span>
                  <span className="font-bold text-white">Daily 11:00 AM – 11:00 PM</span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-zinc-400">Average Pricing:</span>
                  <span className="font-bold text-emerald-400">৳200–400 per person</span>
                </div>
              </div>
            </div>

            {/* Direction Buttons */}
            <div className="pt-4 border-t border-zinc-800 flex flex-wrap gap-2">
              <a
                href="https://maps.google.com/?q=PizzaBurg+Khulna+12+KDA+Ave+Shimla+Plaza"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-gradient-to-r from-red-600 via-red-500 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold py-3 px-4 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 shadow-lg"
              >
                <Navigation className="w-4 h-4" />
                <span>Google Maps Directions</span>
              </a>

              <a
                href="https://www.foodpanda.com.bd"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-pink-700 hover:bg-pink-600 text-white font-bold py-3 px-4 rounded-xl text-xs transition-colors flex items-center justify-center gap-1 shrink-0"
              >
                <span>foodpanda</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Right Map Visual Display */}
          <div className="lg:col-span-7 bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative shadow-2xl flex flex-col min-h-[380px]">
            {/* Embedded Google Map iframe simulation */}
            <iframe
              title="PizzaBurg Khulna Location Map"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: '380px', flex: 1 }}
              loading="lazy"
              allowFullScreen
              src="https://maps.google.com/maps?q=12%20KDA%20Ave,%20Khulna%209100%20Shimla%20Plaza&t=&z=16&ie=UTF8&iwloc=&output=embed"
            ></iframe>

            {/* Overlaid Banner at Bottom of Map */}
            <div className="bg-zinc-950/90 backdrop-blur-md border-t border-zinc-800 p-4 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-red-500" />
                <span className="font-bold text-white">RH93+J9 Khulna • Shimla Plaza</span>
              </div>
              <a
                href="tel:01404461257"
                className="text-amber-400 hover:underline font-bold"
              >
                Call Store
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
