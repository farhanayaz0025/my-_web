import React, { useState } from 'react';
import { CartItem, Order } from './types';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { MenuSection } from './components/MenuSection';
import { PizzaCustomizer } from './components/PizzaCustomizer';
import { AIPizzaAssistant } from './components/AIPizzaAssistant';
import { CombosSection } from './components/CombosSection';
import { ReviewsSection } from './components/ReviewsSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [promoCodeUsed, setPromoCodeUsed] = useState('');
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [activeSection, setActiveSection] = useState('menu');

  // Add Item to Cart Handler
  const handleAddToCart = (newItem: CartItem) => {
    setCartItems((prev) => {
      // Check if exact same item configuration exists
      const existingIdx = prev.findIndex(
        (i) =>
          i.menuItem.id === newItem.menuItem.id &&
          i.selectedSize === newItem.selectedSize &&
          i.selectedCrust === newItem.selectedCrust &&
          JSON.stringify(i.customToppings) === JSON.stringify(newItem.customToppings)
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += newItem.quantity;
        return updated;
      }

      return [...prev, newItem];
    });

    // Auto open cart drawer on add
    setIsCartOpen(true);
  };

  // Update Item Quantity
  const handleUpdateQuantity = (cartId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.cartId === cartId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  // Remove Item
  const handleRemoveItem = (cartId: string) => {
    setCartItems((prev) => prev.filter((item) => item.cartId !== cartId));
  };

  // Open Checkout Modal
  const handleOpenCheckout = (discount: number, promoCode: string) => {
    setDiscountAmount(discount);
    setPromoCodeUsed(promoCode);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Order Placed Handler
  const handleOrderPlaced = (order: Order) => {
    setActiveOrder(order);
    setCartItems([]);
    setIsCheckoutOpen(false);
  };

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-amber-500 selection:text-zinc-950">
      {/* Navigation Header */}
      <Header
        cartItems={cartItems}
        onOpenCart={() => setIsCartOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      {/* Main Content Sections */}
      <main>
        {/* Hero Banner Section */}
        <HeroSection
          onOrderNow={() => scrollToSection('menu')}
          onOpenCustomizer={() => scrollToSection('customizer')}
          onOpenAI={() => scrollToSection('ai-assistant')}
        />

        {/* Menu Section */}
        <MenuSection onAddToCart={handleAddToCart} />

        {/* Value Combos & Deals */}
        <CombosSection onAddToCart={handleAddToCart} />

        {/* Custom Pizza Builder Studio */}
        <PizzaCustomizer onAddToCart={handleAddToCart} />

        {/* AI Craving & Deal Matcher */}
        <AIPizzaAssistant onAddToCart={handleAddToCart} />

        {/* Customer Reviews Section */}
        <ReviewsSection />

        {/* Location, Hours & Directions */}
        <LocationSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Sliding Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onOpenCheckout={handleOpenCheckout}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        discountAmount={discountAmount}
        promoCodeUsed={promoCodeUsed}
        onOrderPlaced={handleOrderPlaced}
      />

      {/* Real-time Order Tracker Modal */}
      <OrderTrackerModal order={activeOrder} onClose={() => setActiveOrder(null)} />
    </div>
  );
}
