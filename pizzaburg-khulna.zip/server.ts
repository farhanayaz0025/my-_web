import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini API client lazily
  let aiClient: GoogleGenAI | null = null;
  function getGenAI() {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error('GEMINI_API_KEY environment variable is not set');
      }
      aiClient = new GoogleGenAI({ apiKey });
    }
    return aiClient;
  }

  // Health check route
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      restaurant: 'PizzaBurg Khulna',
      address: '12 KDA Ave, Khulna 9100',
      rating: 4.9,
      reviewsCount: 1926,
      time: new Date().toISOString()
    });
  });

  // AI Pizza Assistant & Combo Finder API
  app.post('/api/ai-recommend', async (req, res) => {
    try {
      const { peopleCount = 2, budgetBDT = 800, preferences = '', spicyLevel = 'medium' } = req.body;

      const ai = getGenAI();
      const prompt = `You are the expert master chef and deal recommender for "PizzaBurg Khulna", located at 12 KDA Ave, Shimla Plaza, Khulna.
The user is requesting a meal recommendation for ${peopleCount} people with a total budget of ৳${budgetBDT} BDT.
Preferences: "${preferences}".
Spicy tolerance: ${spicyLevel}.

PizzaBurg Khulna signature menu items & prices in BDT:
- PizzaBurg Special Pizza (Personal 8" ৳380, Medium 10" ৳646, Large 12" ৳912)
- Beef Pepperoni Delite (Personal 8" ৳340, Medium 10" ৳578, Large 12" ৳816)
- Chicken BBQ Temptation (Personal 8" ৳320, Medium 10" ৳544, Large 12" ৳768)
- Four Cheese Blast Pizza (Personal 8" ৳350, Medium 10" ৳595, Large 12" ৳840)
- Smoky Sausage Supreme (Personal 8" ৳300, Medium 10" ৳510)
- Garden Veggie Delight (Personal 8" ৳280, Medium 10" ৳476)
- Burg Special Chicken Burger (৳210)
- Cheesy Mushroom Beef Burger (৳260)
- Cheesy Garlic Bread (৳140)
- Spicy BBQ Wings 6pcs (৳220)
- Oven Baked Chicken Pasta (৳280)
- Khulna Student Deal (Personal Pizza + Garlic Bread + Drink 250ml) (৳299)
- Duo Pizza & Burger Box (Medium Pizza + Chicken Burger + Wedges + 2 Drinks) (৳790)
- Family Mega Party Feast (2 Large Pizzas + 6 Wings + Garlic Bread + Fries + 1.25L Drink) (৳1590)
- Warm Chocolate Lava Cake (৳160)
- Soft Drinks 500ml (৳45)

Return a structured JSON output strictly matching this schema:
{
  "suggestionTitle": "Catchy recommendation title",
  "explanation": "Friendly, mouth-watering 2-sentence explanation why this combo fits their group, budget and flavor preferences.",
  "suggestedItems": [
    {
      "itemId": "exact matching item id from above e.g. pizza-burg-special, khulna-student-combo, cheesy-garlic-bread, duo-pizza-box",
      "itemName": "Item Name",
      "size": "8\\" Personal" | "10\\" Medium" | "12\\" Large" | "14\\" Family" or undefined,
      "quantity": 1,
      "price": number_in_bdt,
      "reason": "Short reason"
    }
  ],
  "totalEstimatedCost": number_in_bdt,
  "savingsTip": "Special discount tip e.g. use code PIZZABURG10 for 10% off"
}

Provide output ONLY as valid JSON without markdown formatting code blocks if possible, or standard clean JSON.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        }
      });

      const jsonText = response.text || '{}';
      const parsedData = JSON.parse(jsonText);
      res.json(parsedData);
    } catch (error: any) {
      console.error('Gemini AI Recommendation error:', error);
      // Fallback recommendation if API key is not configured yet
      res.json({
        suggestionTitle: "Khulna PizzaBurg Classic Duo Combo",
        explanation: "A handpicked combination of our customer-favorite PizzaBurg Special along with crispy garlic bread and drinks within your budget!",
        suggestedItems: [
          {
            itemId: "pizza-burg-special",
            itemName: "PizzaBurg Special Pizza",
            size: "10\" Medium",
            quantity: 1,
            price: 646,
            reason: "Flagship favorite packed with BBQ chicken and beef pepperoni"
          },
          {
            itemId: "cheesy-garlic-bread",
            itemName: "Cheesy Garlic Breadsticks",
            quantity: 1,
            price: 140,
            reason: "Golden oven baked starter with melted mozzarella"
          }
        ],
        totalEstimatedCost: 786,
        savingsTip: "Apply promo code PIZZABURG10 at checkout to save 10% instantly!"
      });
    }
  });

  // Order submission simulation API
  app.post('/api/order', (req, res) => {
    const orderData = req.body;
    const orderId = 'PBK-' + Math.floor(100000 + Math.random() * 900000);
    const estimatedMinutes = orderData.deliveryType === 'delivery' ? 30 : 15;

    res.json({
      success: true,
      orderId,
      estimatedMinutes,
      status: 'received',
      message: `Order #${orderId} received successfully! PizzaBurg Khulna team is getting your oven ready at Shimla Plaza.`
    });
  });

  // Vite development middleware vs production static files
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PizzaBurg Khulna Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
