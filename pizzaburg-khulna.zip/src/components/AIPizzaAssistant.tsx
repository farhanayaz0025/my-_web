import React, { useState } from 'react';
import { Sparkles, Users, DollarSign, Flame, ShoppingBag, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { AIRecommendationResponse, CartItem, MenuItem } from '../types';
import { MENU_ITEMS } from '../data/menuData';

interface AIPizzaAssistantProps {
  onAddToCart: (cartItem: CartItem) => void;
}

export const AIPizzaAssistant: React.FC<AIPizzaAssistantProps> = ({ onAddToCart }) => {
  const [peopleCount, setPeopleCount] = useState<number>(3);
  const [budgetBDT, setBudgetBDT] = useState<number>(1000);
  const [preferences, setPreferences] = useState<string>('Love spicy BBQ chicken pizza and crispy garlic bread');
  const [spicyLevel, setSpicyLevel] = useState<'mild' | 'medium' | 'extra_spicy'>('medium');

  const [loading, setLoading] = useState<boolean>(false);
  const [recommendation, setRecommendation] = useState<AIRecommendationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGetRecommendation = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/ai-recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          peopleCount,
          budgetBDT,
          preferences,
          spicyLevel,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to fetch AI recommendation');
      }

      const data: AIRecommendationResponse = await response.json();
      setRecommendation(data);
    } catch (err: any) {
      console.error(err);
      setError('Could not connect to PizzaBurg AI server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddComboToCart = () => {
    if (!recommendation) return;

    recommendation.suggestedItems.forEach((recItem) => {
      // Find matching item in menu or construct item
      const matched = MENU_ITEMS.find((m) => m.id === recItem.itemId) || MENU_ITEMS[0];
      const cartItem: CartItem = {
        cartId: `ai-${recItem.itemId}-${Date.now()}-${Math.random().toString(36).substr(2, 3)}`,
        menuItem: matched,
        selectedSize: recItem.size as any,
        quantity: recItem.quantity,
        calculatedUnitPrice: Math.round(recItem.price / recItem.quantity),
        specialInstructions: `AI Combo Suggestion: ${recItem.reason}`,
      };
      onAddToCart(cartItem);
    });
  };

  return (
    <section id="ai-assistant" className="py-12 bg-zinc-950 text-white border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-300 bg-purple-900/30 border border-purple-500/30 px-3.5 py-1 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            Gemini Powered Craving Matcher
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            PizzaBurg <span className="text-purple-400">AI Taste & Deal Finder</span>
          </h2>
          <p className="text-sm text-zinc-400">
            Not sure what to order? Tell our AI chef how many people are eating and your budget in BDT (৳). We'll build the best combo deal for you!
          </p>
        </div>

        {/* Interactive Query Form & Results */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Query Inputs Card */}
          <div className="lg:col-span-5 bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 space-y-5 shadow-xl">
            <h3 className="font-extrabold text-lg text-white flex items-center gap-2 border-b border-zinc-800 pb-3">
              <Users className="w-5 h-5 text-purple-400" /> Your Meal Preferences
            </h3>

            {/* People Count Slider */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-zinc-300">
                <span>Number of People Eating:</span>
                <span className="text-purple-400 font-extrabold text-sm">{peopleCount} Person(s)</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={peopleCount}
                onChange={(e) => setPeopleCount(parseInt(e.target.value))}
                className="w-full accent-purple-500 bg-zinc-800 rounded-lg cursor-pointer h-2"
              />
            </div>

            {/* Budget Slider */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-zinc-300">
                <span>Total Budget (BDT ৳):</span>
                <span className="text-emerald-400 font-extrabold text-sm">৳{budgetBDT}</span>
              </div>
              <input
                type="range"
                min="200"
                max="3000"
                step="50"
                value={budgetBDT}
                onChange={(e) => setBudgetBDT(parseInt(e.target.value))}
                className="w-full accent-emerald-500 bg-zinc-800 rounded-lg cursor-pointer h-2"
              />
            </div>

            {/* Flavor preference input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-zinc-300">
                Taste Preferences / Craving Details
              </label>
              <textarea
                rows={3}
                value={preferences}
                onChange={(e) => setPreferences(e.target.value)}
                placeholder="e.g. Extra cheese, pepperoni, spicy chicken, need drinks, vegetarian options..."
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500 resize-none"
              />
            </div>

            {/* Spicy Tolerance */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-zinc-300">Spicy Level Tolerance</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'mild', label: 'Mild Flavor' },
                  { id: 'medium', label: 'Medium Spicy' },
                  { id: 'extra_spicy', label: 'Extra Spicy Fire' },
                ].map((lvl) => (
                  <button
                    key={lvl.id}
                    onClick={() => setSpicyLevel(lvl.id as any)}
                    className={`p-2 rounded-xl border text-[11px] font-bold transition-all ${
                      spicyLevel === lvl.id
                        ? 'bg-purple-900/60 border-purple-500 text-purple-200'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {lvl.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              onClick={handleGetRecommendation}
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-sm disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Chef AI is Crafting Your Menu...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-purple-200" />
                  <span>Generate AI Meal Recommendation</span>
                </>
              )}
            </button>
          </div>

          {/* AI Result Card */}
          <div className="lg:col-span-7 bg-zinc-900/90 border border-purple-900/40 rounded-3xl p-6 shadow-2xl relative space-y-6">
            {!recommendation && !loading && (
              <div className="text-center py-16 space-y-3">
                <div className="w-16 h-16 rounded-full bg-purple-950 border border-purple-800/80 mx-auto flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-purple-400" />
                </div>
                <h4 className="font-extrabold text-base text-zinc-200">
                  Ready to discover your perfect PizzaBurg meal?
                </h4>
                <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                  Adjust your party size and budget on the left, then click "Generate AI Meal Recommendation".
                </p>
              </div>
            )}

            {loading && (
              <div className="text-center py-20 space-y-4">
                <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-xs text-purple-300 font-bold">
                  Analyzing PizzaBurg Khulna menu for {peopleCount} people under ৳{budgetBDT}...
                </p>
              </div>
            )}

            {recommendation && !loading && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="border-b border-zinc-800 pb-4">
                  <div className="inline-flex items-center gap-1.5 text-[11px] font-bold text-purple-400 bg-purple-950/80 px-3 py-0.5 rounded-full mb-2 border border-purple-800/60">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> AI Matched Combo
                  </div>
                  <h3 className="font-black text-xl text-white">{recommendation.suggestionTitle}</h3>
                  <p className="text-xs text-zinc-300 mt-2 leading-relaxed bg-zinc-950/60 p-3 rounded-2xl border border-zinc-800">
                    {recommendation.explanation}
                  </p>
                </div>

                {/* Items List */}
                <div className="space-y-3">
                  <h4 className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                    Recommended Items:
                  </h4>
                  <div className="space-y-2.5">
                    {recommendation.suggestedItems.map((item, idx) => (
                      <div
                        key={idx}
                        className="bg-zinc-950 border border-zinc-800 rounded-2xl p-3.5 flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-bold text-xs text-white flex items-center gap-2">
                            <span>{item.itemName}</span>
                            {item.size && (
                              <span className="text-[10px] bg-red-950 text-red-300 border border-red-800/80 px-2 py-0.2 rounded-full font-semibold">
                                {item.size}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-zinc-400 mt-0.5">{item.reason}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-xs font-black text-amber-400">৳{item.price}</div>
                          <div className="text-[10px] text-zinc-500">Qty: {item.quantity}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cost & Savings Summary */}
                <div className="bg-gradient-to-r from-purple-950/80 to-zinc-950 border border-purple-800/50 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-[11px] text-zinc-400">Total Estimated Cost</div>
                    <div className="text-lg font-black text-emerald-400">
                      ৳{recommendation.totalEstimatedCost} BDT
                    </div>
                  </div>
                  {recommendation.savingsTip && (
                    <div className="text-xs text-purple-300 font-semibold bg-purple-900/40 px-3 py-1.5 rounded-xl border border-purple-700/50">
                      💡 {recommendation.savingsTip}
                    </div>
                  )}
                </div>

                {/* Add to Cart CTA */}
                <button
                  onClick={handleAddComboToCart}
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-extrabold py-3.5 px-6 rounded-2xl shadow-xl flex items-center justify-center gap-2 text-sm transition-all"
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>Add Entire Recommended Combo to Cart (৳{recommendation.totalEstimatedCost})</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
